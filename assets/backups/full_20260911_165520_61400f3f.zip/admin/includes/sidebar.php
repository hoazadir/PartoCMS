<?php
/**
 * Sidebar استاندارد برای همه صفحات ادمین
 */
if (!isset($siteName)) {
    $siteName = function_exists('getSetting') ? getSetting('site_name', 'وب‌سایت من') : 'وب‌سایت من';
}

$currentFile = basename($_SERVER['PHP_SELF']);
$currentPath = $_SERVER['PHP_SELF'];

$userRole = $_SESSION['role'] ?? 'user';
$isAdmin = $userRole === 'admin';

$isContentGroup = in_array($currentFile, ['categories.php', 'media.php', 'comments.php', 'admin.php']) || strpos($currentPath, 'modules/content') !== false;
$isModulesGroup = in_array($currentFile, ['forms.php', 'form-edit.php', 'form-submissions.php', 'menus.php', 'menu-edit.php']);
$isAppearanceGroup = in_array($currentFile, ['templates.php', 'editor.php']);
$isUsersGroup = in_array($currentFile, ['users.php', 'roles.php']);
$isSettingsGroup = in_array($currentFile, ['modules.php', 'settings.php', 'seo.php']);
?>
<style>
    .sidebar {
        background: #1e293b;
        min-height: 100vh;
        color: #fff;
        padding: 0;
        position: fixed;
        right: 0;
        top: 0;
        width: 260px;
        z-index: 100;
        overflow-y: auto;
        box-shadow: -2px 0 10px rgba(0,0,0,0.15);
        display: flex;
        flex-direction: column;
    }
    .sidebar::-webkit-scrollbar { width: 5px; }
    .sidebar::-webkit-scrollbar-thumb { background: #475569; border-radius: 5px; }

    .sidebar .brand {
        padding: 22px 20px;
        text-align: center;
        border-bottom: 1px solid #334155;
        background: linear-gradient(135deg, #1e293b, #334155);
        flex-shrink: 0;
    }
    .sidebar .brand h5 { margin: 0 0 5px; font-size: 16px; font-weight: bold; color: #fff; }
    .sidebar .brand small { opacity: 0.6; font-size: 11px; display: block; color: #cbd5e1; }
    .sidebar .brand .logo-icon { font-size: 28px; display: block; margin-bottom: 8px; }

    .user-info-box {
        padding: 12px 20px;
        background: #0f172a;
        border-bottom: 1px solid #334155;
        display: flex;
        align-items: center;
        gap: 10px;
        flex-shrink: 0;
    }
    .user-info-box .avatar {
        width: 36px; height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, #3b82f6, #8b5cf6);
        display: flex; align-items: center; justify-content: center;
        color: #fff; font-weight: bold; font-size: 15px;
        flex-shrink: 0;
    }
    .user-info-box .info { flex: 1; min-width: 0; }
    .user-info-box .info .name {
        font-size: 13px; font-weight: bold; color: #fff;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .user-info-box .info .role { font-size: 10px; color: #94a3b8; }

    .menu-group { border-bottom: 1px solid #334155; }
    .menu-group-header {
        padding: 14px 20px;
        display: flex;
        align-items: center;
        gap: 12px;
        cursor: pointer;
        transition: all 0.2s;
        font-size: 14px;
        font-weight: bold;
        color: #cbd5e1;
        user-select: none;
    }
    .menu-group-header:hover { background: #334155; color: #fff; }
    .menu-group-header .group-icon { font-size: 18px; width: 22px; text-align: center; }
    .menu-group-header .group-title { flex: 1; }
    .menu-group-header .arrow {
        font-size: 11px;
        transition: transform 0.3s;
        color: #64748b;
    }
    .menu-group.open .menu-group-header { background: #334155; color: #fff; }
    .menu-group.open .menu-group-header .arrow { transform: rotate(180deg); }
    .menu-group.has-active .menu-group-header { color: #3b82f6; }

    .menu-group-items {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.35s ease;
        background: #0f172a;
    }
    .menu-group.open .menu-group-items { max-height: 600px; }

    .menu-group-items a {
        padding: 11px 20px 11px 45px;
        display: flex;
        align-items: center;
        gap: 10px;
        color: #94a3b8;
        text-decoration: none;
        font-size: 13px;
        border-right: 3px solid transparent;
        transition: all 0.2s;
    }
    .menu-group-items a:hover {
        background: #1e293b;
        color: #fff;
        border-right-color: #3b82f6;
    }
    .menu-group-items a.active {
        background: linear-gradient(90deg, transparent, rgba(59,130,246,0.15));
        color: #fff;
        border-right-color: #3b82f6;
        font-weight: bold;
    }
    .menu-group-items a .item-icon { font-size: 14px; width: 18px; text-align: center; }

    .menu-single {
        padding: 14px 20px;
        display: flex;
        align-items: center;
        gap: 12px;
        color: #cbd5e1;
        text-decoration: none;
        font-size: 14px;
        transition: all 0.2s;
        border-bottom: 1px solid #334155;
        border-right: 3px solid transparent;
    }
    .menu-single:hover { background: #334155; color: #fff; }
    .menu-single.active {
        background: linear-gradient(90deg, transparent, rgba(59,130,246,0.2));
        color: #fff;
        border-right-color: #3b82f6;
        font-weight: bold;
    }
    .menu-single .single-icon { font-size: 18px; width: 22px; text-align: center; }
    .menu-single.danger { color: #f87171; }
    .menu-single.danger:hover { background: #7f1d1d; color: #fff; }

    .menu-bottom {
        margin-top: auto;
        border-top: 2px solid #334155;
        padding-top: 5px;
    }

    @media (max-width: 900px) {
        .sidebar { width: 70px; }
        .sidebar .brand h5, .sidebar .brand small, .sidebar .brand .logo-icon,
        .user-info-box .info, .menu-group-header .group-title,
        .menu-group-header .arrow, .menu-single span:not(.single-icon),
        .menu-group-items a span:not(.item-icon) { display: none; }
        .menu-group-header, .menu-single { justify-content: center; padding: 15px 5px; }
        .menu-group-items a { padding: 12px 5px; justify-content: center; }
        .user-info-box { justify-content: center; }
        .menu-group.open .menu-group-items { max-height: 0; }
    }
</style>

<div class="sidebar" id="adminSidebar">

    <div class="brand">
        <span class="logo-icon">🚀</span>
        <h5>پنل مدیریت</h5>
        <small><?= htmlspecialchars($siteName) ?></small>
    </div>

    <?php if (isset($_SESSION['username'])): ?>
    <div class="user-info-box">
        <div class="avatar"><?= htmlspecialchars(mb_substr($_SESSION['username'], 0, 1)) ?></div>
        <div class="info">
            <div class="name"><?= htmlspecialchars($_SESSION['username']) ?></div>
            <div class="role"><?= htmlspecialchars($_SESSION['role_name'] ?? 'کاربر') ?></div>
        </div>
    </div>
    <?php endif; ?>

    <a href="index.php" class="menu-single <?= $currentFile === 'index.php' ? 'active' : '' ?>">
        <span class="single-icon">📊</span>
        <span>داشبورد</span>
    </a>

    <a href="reports.php" class="menu-single <?= $currentFile === 'reports.php' ? 'active' : '' ?>">
        <span class="single-icon">📈</span>
        <span>گزارش‌ها</span>
    </a>

    <a href="seo.php" class="menu-single <?= $currentFile === 'seo.php' ? 'active' : '' ?>">
        <span class="single-icon">🔍</span>
        <span>تنظیمات SEO</span>
    </a>

    <a href="backups.php" class="menu-single <?= $currentFile === 'backups.php' ? 'active' : '' ?>">
        <span class="single-icon">💾</span>
        <span>پشتیبان‌گیری</span>
    </a>

    <div class="menu-group <?= $isContentGroup ? 'open has-active' : '' ?>" data-group="content">
        <div class="menu-group-header" onclick="toggleMenuGroup(this)">
            <span class="group-icon">📝</span>
            <span class="group-title">مدیریت محتوا</span>
            <span class="arrow">▼</span>
        </div>
        <div class="menu-group-items">
            <a href="../modules/content/admin.php" class="<?= strpos($currentPath, 'modules/content') !== false ? 'active' : '' ?>">
                <span class="item-icon">📄</span>
                <span>مقالات و صفحات</span>
            </a>
            <a href="categories.php" class="<?= $currentFile === 'categories.php' ? 'active' : '' ?>">
                <span class="item-icon">🏷</span>
                <span>دسته‌بندی‌ها</span>
            </a>
            <a href="media.php" class="<?= $currentFile === 'media.php' ? 'active' : '' ?>">
                <span class="item-icon">🖼</span>
                <span>رسانه‌ها</span>
            </a>
            <a href="comments.php" class="<?= $currentFile === 'comments.php' ? 'active' : '' ?>">
                <span class="item-icon">💬</span>
                <span>دیدگاه‌ها</span>
            </a>
        </div>
    </div>

    <div class="menu-group <?= $isModulesGroup ? 'open has-active' : '' ?>" data-group="modules">
        <div class="menu-group-header" onclick="toggleMenuGroup(this)">
            <span class="group-icon">🧩</span>
            <span class="group-title">ابزارها</span>
            <span class="arrow">▼</span>
        </div>
        <div class="menu-group-items">
            <a href="forms.php" class="<?= in_array($currentFile, ['forms.php', 'form-edit.php', 'form-submissions.php']) ? 'active' : '' ?>">
                <span class="item-icon">📋</span>
                <span>فرم‌ساز</span>
            </a>
            <a href="menus.php" class="<?= in_array($currentFile, ['menus.php', 'menu-edit.php']) ? 'active' : '' ?>">
                <span class="item-icon">🔗</span>
                <span>منوساز</span>
            </a>
        </div>
    </div>

    <div class="menu-group <?= $isAppearanceGroup ? 'open has-active' : '' ?>" data-group="appearance">
        <div class="menu-group-header" onclick="toggleMenuGroup(this)">
            <span class="group-icon">🎨</span>
            <span class="group-title">ظاهر سایت</span>
            <span class="arrow">▼</span>
        </div>
        <div class="menu-group-items">
            <a href="templates.php" class="<?= $currentFile === 'templates.php' ? 'active' : '' ?>">
                <span class="item-icon">📦</span>
                <span>مدیریت قالب‌ها</span>
            </a>
            <a href="editor.php" class="<?= $currentFile === 'editor.php' ? 'active' : '' ?>">
                <span class="item-icon">✏️</span>
                <span>طراح قالب</span>
            </a>
        </div>
    </div>

    <?php if ($isAdmin): ?>
    <div class="menu-group <?= $isUsersGroup ? 'open has-active' : '' ?>" data-group="users">
        <div class="menu-group-header" onclick="toggleMenuGroup(this)">
            <span class="group-icon">👥</span>
            <span class="group-title">کاربران</span>
            <span class="arrow">▼</span>
        </div>
        <div class="menu-group-items">
            <a href="users.php" class="<?= $currentFile === 'users.php' ? 'active' : '' ?>">
                <span class="item-icon">👤</span>
                <span>لیست کاربران</span>
            </a>
            <a href="roles.php" class="<?= $currentFile === 'roles.php' ? 'active' : '' ?>">
                <span class="item-icon">🛡</span>
                <span>نقش‌ها و دسترسی</span>
            </a>
        </div>
    </div>

    <div class="menu-group <?= $isSettingsGroup ? 'open has-active' : '' ?>" data-group="settings">
        <div class="menu-group-header" onclick="toggleMenuGroup(this)">
            <span class="group-icon">⚙️</span>
            <span class="group-title">تنظیمات</span>
            <span class="arrow">▼</span>
        </div>
        <div class="menu-group-items">
            <a href="modules.php" class="<?= $currentFile === 'modules.php' ? 'active' : '' ?>">
                <span class="item-icon">🧩</span>
                <span>ماژول‌ها</span>
            </a>
            <a href="settings.php" class="<?= $currentFile === 'settings.php' ? 'active' : '' ?>">
                <span class="item-icon">🛠</span>
                <span>تنظیمات سایت</span>
            </a>
        </div>
    </div>
    <?php endif; ?>

    <div class="menu-bottom">
        <a href="../index.php" target="_blank" class="menu-single">
            <span class="single-icon">🌐</span>
            <span>مشاهده سایت</span>
        </a>
        <a href="logout.php" class="menu-single danger">
            <span class="single-icon">🚪</span>
            <span>خروج</span>
        </a>
    </div>

</div>

<script>
function toggleMenuGroup(header) {
    const group = header.parentElement;
    const groupName = group.dataset.group;

    group.classList.toggle('open');

    if (groupName) {
        let openGroups = JSON.parse(localStorage.getItem('sidebar_open_groups') || '[]');
        if (group.classList.contains('open')) {
            if (!openGroups.includes(groupName)) openGroups.push(groupName);
        } else {
            openGroups = openGroups.filter(n => n !== groupName);
        }
        localStorage.setItem('sidebar_open_groups', JSON.stringify(openGroups));
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const openGroups = JSON.parse(localStorage.getItem('sidebar_open_groups') || '[]');
    document.querySelectorAll('.menu-group').forEach(group => {
        const name = group.dataset.group;
        if (name && openGroups.includes(name)) {
            group.classList.add('open');
        }
        if (group.classList.contains('has-active')) {
            group.classList.add('open');
        }
    });
});
</script>
