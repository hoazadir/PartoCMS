<?php
require_once __DIR__ . '/../config.php';

// چک لاگین
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}
$perm = getPermissions();
$perm->require('modules.manage');

$pdo = getDB();
$mm = getModuleManager();

// فعال/غیرفعال
if (isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $stmt = $pdo->prepare("SELECT slug, is_enabled FROM modules WHERE id = ?");
    $stmt->execute([$_GET['toggle']]);
    $mod = $stmt->fetch();
    if ($mod) {
        $mod['is_enabled'] ? $mm->disable($mod['slug']) : $mm->enable($mod['slug']);
        header('Location: modules.php?msg=updated');
        exit;
    }
}

// نصب ماژول
if (isset($_GET['install'])) {
    $slug = preg_replace('/[^a-z0-9_-]/', '', $_GET['install']);
    $installFile = __DIR__ . "/../modules/{$slug}/install.php";
    if (file_exists($installFile)) {
        $installer = include $installFile;
        if (is_callable($installer)) {
            $installer($pdo, $mm);
            $mm->enable($slug);
            header('Location: modules.php?msg=installed');
            exit;
        }
    }
}

$modules = $mm->getAll();
$siteName = getSetting('site_name', 'وب‌سایت من');
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت ماژول‌ها | <?= htmlspecialchars($siteName) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body { font-family: Tahoma, sans-serif; background: #f4f6f9; margin: 0; }
        .sidebar { background: #2c3e50; min-height: 100vh; color: #fff; padding: 0; position: fixed; right: 0; top: 0; width: 240px; }
        .sidebar .brand { padding: 20px; text-align: center; border-bottom: 1px solid #34495e; }
        .sidebar a { color: #ecf0f1; text-decoration: none; padding: 14px 20px; display: block; border-bottom: 1px solid #34495e; font-size: 14px; transition: background 0.2s; }
        .sidebar a:hover, .sidebar a.active { background: #3498db; }
        .main { margin-right: 240px; padding: 25px; }
        .module-card { background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.06); }
    </style>
</head>
<body>

<?php require_once __DIR__ . '/includes/sidebar.php'; ?>

<div class="main">
    <h4 class="mb-4">🧩 مدیریت ماژول‌ها</h4>

    <?php if (isset($_GET['msg'])): ?>
        <div class="alert alert-success">✅ عملیات با موفقیت انجام شد</div>
    <?php endif; ?>

    <div class="row g-3">
        <?php foreach ($modules as $mod): ?>
            <div class="col-md-6">
                <div class="module-card">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h5 style="color:#2c3e50; margin:0 0 8px;"><?= htmlspecialchars($mod['name']) ?></h5>
                            <p style="color:#7f8c8d; font-size:13px; margin:0 0 10px;"><?= htmlspecialchars($mod['description']) ?></p>
                            <span class="badge bg-secondary">v<?= htmlspecialchars($mod['version']) ?></span>
                        </div>
                        <div>
                            <?php if ($mod['is_enabled']): ?>
                                <span class="badge bg-success mb-2 d-block">فعال</span>
                                <a href="?toggle=<?= $mod['id'] ?>" class="btn btn-sm btn-outline-warning">غیرفعال</a>
                                <?php if ($mod['slug'] === 'content'): ?>
                                    <a href="../modules/content/admin.php" class="btn btn-sm btn-primary mt-2 w-100">
                                        <i class="bi bi-box-arrow-in-left"></i> ورود به ماژول
                                    </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="badge bg-secondary mb-2 d-block">غیرفعال</span>
                                <a href="?toggle=<?= $mod['id'] ?>" class="btn btn-sm btn-success">فعال‌سازی</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if (empty($modules)): ?>
        <div class="alert alert-info text-center py-5">
            <i class="bi bi-puzzle fs-1 d-block mb-3"></i>
            هیچ ماژولی نصب نشده است.
        </div>
    <?php endif; ?>
</div>
</body>
</html>
